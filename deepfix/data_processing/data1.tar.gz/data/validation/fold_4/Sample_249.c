#include<stdio.h>

int capitalize(char *p_to, char *p_from)
{
  char ch;   
  while(1)   
  {
    ch = *p_from; 
    if(('a'<=ch)&&(ch<='z'))ch = ch-('a'-'A');
      *p_to = ch;
    if(ch=='\0')break;
      p_to+=1;
      p_from+=1; 
  }
  return 1;
}

int main()
{
char buffer[10];
capitalize(buffer, "teststring");
  printf(buffer);
}

