#include <stdio.h>
int capitalize(char *p_to, char *p_from, int *p_len)
{
	char ch;
	while(1)
	{
		ch = *p_from;
		if(('a' <= ch)&&(ch <= 'z')) ch = ch - ('a' - 'A'); 
		if(ch == '\0') break;
		*p_to = ch;
		p_from++;
		p_to++;
		(*p_len)++;
	}
	return 1;
}

int main()
{
	char buffer[100]="a", str[100]="a";
	int len = 0;
	scanf("%[^\n]", str);
	capitalize(buffer, str, &len);
	printf("[%s][%d]", buffer, len);
	return 0;
}

