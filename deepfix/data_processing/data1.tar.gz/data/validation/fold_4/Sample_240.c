#include <stdio.h>
int capitalize(char *p_to, char *p_from, int *len)
{
      int i=0;
      char ch;
      while(i<100)
      {     
           ch = *p_from;
           if(ch==0)break;
           if(('a'<=ch)&&(ch<='z'))ch = ch - ('a'-'A');
           *p_to = ch;
           *len=i;
           printf("%c %d\n",*p_to,*len);
           p_to=p_to+1;
           p_from=p_from+1;
           i=i+1;
      }
      return 1;
}

int main()
{
     char buffer[100];
     int len=0;
     capitalize(buffer, "teststring", &len);
}

