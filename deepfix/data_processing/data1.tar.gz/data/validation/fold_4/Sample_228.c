#include <stdio.h>
int capitalize(char *p_to, char *p_from, int *len)
{
	char ch;
         int count=1;
	int i=0;
	ch=*p_from;
while(1)
	{
	ch=*p_from;
        if(('a'<=ch)&&(ch<='z')) ch=ch-('a'-'A');
		*p_to=ch;
	    p_to=p_to+1;
   p_from=p_from+1;
   *len=count++;
		i++;
            if(ch=='\0')
             {
                *p_to=ch;
                 break;  
             }
	}
	return *p_to;
}
int main()
{
	char buffer[100];
	int len;  
	capitalize(buffer, "teststring",&len);
	printf("%s\n", buffer);
         printf("%d\n",len);
	return 0;
}
