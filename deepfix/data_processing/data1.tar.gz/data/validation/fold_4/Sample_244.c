


#include<stdio.h>

int capitalize(char *p_to, char *p_from,int *p_len)
{
	char ch;
	int i=0;
	while(1)
	{
		ch = *p_from;
		if(('a'<=ch)&&(ch<='z'))ch = ch - ('a'-'A');
  		*p_to = ch;
		p_from=p_from+1;
		p_to=p_to+1;
		if(ch=='\0')break;
		i++;
	}
	*p_len=i;
}

int main()
{
	char buffer[100];
	int len;
	capitalize(buffer, "test string",&len);
	printf(buffer);
	printf("\n");
	printf("%d",len);
}

