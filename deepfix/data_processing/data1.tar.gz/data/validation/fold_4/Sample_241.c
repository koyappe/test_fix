

#include <stdio.h>
int capitalize(char *p_to, char *p_from, int *len)
{
 	char ch;
	int a =0;

	while(1)
	{
		ch = *p_from;
		if(('a' <= ch)&&(ch <='z')) ch = ch-('a'-'A');
		else if(('A' <= ch)&&(ch <='Z')) ch = ch+('a'-'A');
		*p_to = ch;
		if(*p_from == '\0')break;
		p_to++;
		p_from++;
		a++;
	}
  *len = a; 
  return 1;
}


int main()
{
	char buffer[100];
	char nyuu[100];
	int len;
	scanf("%s",nyuu);
	capitalize(buffer, nyuu, &len);
	printf("�ҏW��F");
	printf(buffer);
	printf("\n������:%d",len);
}
