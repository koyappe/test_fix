#include<stdio.h>

int capitalize(char *p_to, char *p_from, int *len){
	char ch;
	int i;

	while(1)
	{
		ch = *p_from;				
		if(ch=='\0')break;			
		if(('a'<=ch)&&(ch<='z')){			
			ch = ch-('a'-'A');			
			*p_to = ch;
		
			p_to++;
			p_from++;
			(*len)++;
		}
     else{
    		p_to++;
			p_from++;
			
		}
	}

}

int main(){
	char buffer[100];	
	int len = 0;
	capitalize(buffer, " teststring ", &len);
	printf("%s \n%d\n", buffer, len);
}

