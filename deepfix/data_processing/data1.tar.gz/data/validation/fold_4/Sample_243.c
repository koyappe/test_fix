

#include<stdio.h>

int capitalize(char *p_to,char *p_from,int *p_len)
{
   int i=0;
   char ch;
   while(1)
   {
       ch = *p_from;
       if(('a'<=ch)&&(ch<='z'))ch = ch - ('a'-'A');
       *p_to = ch;
       p_from = p_from+1;
       p_to = p_to+1;
			i++;
       if(ch=='\0') break;
     }
     *p_len=i;
}

int main()
{
    char buffer[100];
    int len=0;
    capitalize(buffer, "test string", &len);
    printf(buffer);
    printf("\n");
    printf("%d",len);
}

