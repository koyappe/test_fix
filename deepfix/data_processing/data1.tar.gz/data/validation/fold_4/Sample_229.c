
#include<stdio.h>
int capitalize(char *p_to, char *p_from, int *len)
{    
char ch;
        *len=0;
 while(1){
            ch=*p_from;
            *p_to=ch;
            if(ch=='\0'){break;}
                if(('a'<=ch)&&(ch<='z')){
                     ch = ch - ('a'-'A');
                     *len=*len+1;
                                        }
        *p_to=ch;
        p_from=p_from+1;
        p_to=p_to+1;
             }
       return 1;
}
int main()
{
     char buffer[100];
     int len;
     capitalize(buffer, "test string ", &len);
     printf(buffer);
     printf("�ϊ����ꂽ������̒��� %d\n",len);
     return 0;
}
