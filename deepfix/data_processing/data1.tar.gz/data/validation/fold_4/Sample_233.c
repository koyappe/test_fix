#include<stdio.h>

int capitalize(char *p_to,char *p_from, int *len){
	int i;
	char ch;
	ch = *p_from;
	for(i=0;i<100;i++){
		if(ch=='\0')break;
		if(*p_from>='a'&& *p_from<='z'){
			ch = *p_from;
			*p_to=(ch-('a'-'A'));
			(*len)++;
			p_to+=1;
			p_from+=1;
		}else{
			ch = *p_from;
			*p_to=ch;
			p_to+=1;
			p_from+=1;
		}
	}
	return 1;
}
int main(){
	char buffer[100];
  int len=0;
	capitalize(buffer, "teststring", &len);
  printf("�ϊ���̕�����́@%s \n�ϊ�����%d",buffer,len);
}

