
#include <stdio.h>
#define BUFFER_SIZE 100
int count_str(char *str)
{
	int count=1;
	while(*str!='\0')
	{
		count++;
		str++;
	}
	return count;
}

int capitalize(char *p_to, char *p_from, int *len)
{
	int i,ns;					
	char ch;					

	ns=count_str(p_from);					

	if((p_from+ns)<p_to)				
	{
		for(i=0;i<BUFFER_SIZE;i++)		
		{
			ch=*p_from;
			if(ch>='a'&&ch<='z')		
			{
				ch=ch-('a'-'A');
				(*len)++;
			}
			*p_to=ch;
	
			if(ch=='\0') break;		
	
			p_to=p_to+1;
			p_from=p_from+1;
		}
	}
	else
	{
		p_from=p_from+ns-1;
		p_to=p_to+ns-1;
		for(i=0;i<ns;i++)			
		{
			ch=*p_from;
			if(ch>='a'&&ch<='z')		
			{
				ch=ch-('a'-'A');
				(*len)++;
			}
			*p_to=ch;

			p_to=p_to-1;
			p_from=p_from-1;
		}
	}

	return 1;
}

int main()
{
	char buffer[BUFFER_SIZE];
	int len=0;

	capitalize(buffer, "test string", &len);

	printf(buffer);
	printf("\n");
	printf("�ϊ����������� = %d\n",len);

	return 0;
}
