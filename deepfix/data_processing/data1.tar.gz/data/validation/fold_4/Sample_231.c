#include <stdio.h>

int capitalize(char *p_to, char *p_from, int *len)
{
  char ch;
  while(1)
  {
  ch = *p_from;
    if(ch>='a' && ch<='z')
    {
      if(('a'<=ch)&&(ch<='z'))ch=ch-('a'-'A');
      *p_to = ch;
      *p_from++;
      *p_to++;
      *len++;
    }else{
      return 1;
    }
  }
}

int main()
{
  char buffer[100];
	int len;
	capitalize(buffer, "teststring", &len);
  printf(buffer);
}

