#include <stdio.h>

int capitalize(char *p_to, char *p_from, int *len)
{
    char ch;
    while(*p_from!='\0'){
    ch=*p_from;
    if(('a'<=ch)&&(ch<'z'))ch = ch - ('a'-'A');
    *p_to=ch;
    p_from=p_from+1;
    p_to=p_to+1;
    *len=len+1;
    }
    return 1;
}

int main()
{
char buffer[100];
	int len;
	capitalize(buffer, "teststring", &len);
  printf(buffer);
  printf("%d\n",len);
}

