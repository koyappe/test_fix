

#include<stdio.h>

int capitalize(char *p_to, char *p_from, int *len)
{
	char ch;
	int i=0;
	while(1)
	{
		if(*p_from=='\0')
		{
			*p_to =*p_from;
			return *p_to;
		}
		else//
		{
			ch = *p_from;
			if(('a'<=ch)&&(ch<='z'))ch = ch-('a'-'A');
			*p_to = ch;
			printf("%c\n",*p_to);
			p_from=p_from+1;
			p_to=p_to+1;
			++*len;

		}
	}

}

int main()
{
	char buffer[100];
	int len;
  capitalize(buffer, "teststring", &len);
	printf(buffer);
	printf("\n%d\n",len);	
}
