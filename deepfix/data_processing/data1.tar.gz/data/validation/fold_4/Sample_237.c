#include<stdio.h>
int capitalize(char *p_to, char *p_from, int *len)
{
  char ch;
  while(1)
  {
    if(*p_from=='\0')
    {
      *p_to=*p_from;
      break;
    }
    ch = *p_from;
    if (('a' <= ch) && (ch <= 'z')) ch = ch - ('a'-'A');
    *p_to = ch;
     p_from=p_from+1;
     p_to=p_to+1;
  }
  return 0;
}


int main()
{
  char buffer[100];
	int len;
	capitalize(buffer, "teststring", &len);
  printf(buffer);
}

