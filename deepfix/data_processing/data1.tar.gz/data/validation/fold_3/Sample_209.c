#include<stdio.h>

struct record
{
  int eng, math, phy;
};

struct query
{
  char f1, op, f2;
};



struct record database[20]=
{
  {27,54,49},
  {55,99,56},
  {96,81,100},
  {28,80,90},
  {22,57,31},
  {94,75,73},
  {60,59,67},
  {64,79,30},
  {29,77,57},
  {62,47,95},
  {93,23,23},
  {73,63,59},
  {34,57,27},
  {51,62,86},
  {73,76,28},
  {72,96,64},
  {24,76,73},
  {98,91,88},
  {70,78,80},
  {60,98,95}
};

int get_field(char i, struct record database)
{
  if(i=='e')
  {
    return database.eng;
  }
  else if(i=='m')
  {
    return database.math;
  }
  else if(i=='p')
  {
    return database.phy;
  }
  else
  {
    return 0;
  }
}

int check_record(struct record database, struct query p)
{
  switch(p.op)
  {
    case '>':
      if(get_field(p.f1, database)>get_field(p.f2, database))
      {
        return 1;
      }
	  else
	  {
	    return 0;
	  }

    case'<':
      if(get_field(p.f1, database)<get_field(p.f2, database))
      {
        return 1;
      }
	  else
	  {
	    return 0;
	  }

    case'=':
      if(get_field(p.f1, database)==get_field(p.f2, database))
      {
        return 1;
      }
	    else
	    {
	      return 0;
	    }

    default:
      return 0;

  }
}

int main()
{
  int i;
  struct query q;
  while(1)
  {
    scanf("%c %c %c", &q.f1, &q.op, &q.f2);
    fflush(stdin);
    for(i=0; i<20; i++)
    {
      if(check_record(database[i], q)==1)
	  {
	     printf("%d", i+1);
	  }
    }
  }
}
