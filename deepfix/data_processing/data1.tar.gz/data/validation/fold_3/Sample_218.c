#include <stdio.h>
#define N 100

int capitalize(char *p_to, char *p_from, int *len)
{
	char ch;
	while(1)
	{
		ch = *p_from;
		if((ch>='a')&&(ch<='z'))			
		{
			ch = ch - ('a'-'A');		
		}
		*p_to = ch;				

		if(ch=='\0')break;			
		p_from++;
		p_to++;
		(*len)++;
	}
	return 1;
}

int main()
{
	char buffer[N];				
	int len;					
	len = 0;
	capitalize(buffer, "test string", &len);
	printf("[%d] %s",len,buffer);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 100

int capitalize(char *p_to, char *p_from, int *len)
{
	char ch;
	int l_from, l_to, flag=0;
	l_from = strlen(p_from);
	l_to = strlen(p_to);

	if(p_to < p_from) flag = 0;
	else if(p_to == p_from) flag = 1;
	else if(p_to > p_from) flag = 2;
	printf("%d\n",flag);
	switch(flag)
		{
			case 2:			
				p_from += l_from;
				p_to += l_to;
				break;
		}

	while(1)
	{
		ch = *p_from;

		if((ch>='a')&&(ch<='z'))		
			ch = ch - ('a'-'A');	
		
		*p_to = ch;			

		if(ch=='\0')break;		

		switch(flag)
		{
			case 0:
				p_from++;
				p_to++;
				break;
			case 1:
				p_from++;
				p_to++;
				break;
			case 2:
				p_from--;
				p_to--;
				break;
		}
		(*len)++;
	}
	return 1;
}

int main()
{
	char buffer[N];				
	int len;					
	len = 0;
	capitalize(buffer, "test string", &len);	
	printf("[%d] %s",len,buffer);
}
