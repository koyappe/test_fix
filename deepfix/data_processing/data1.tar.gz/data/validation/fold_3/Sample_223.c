#include<stdio.h>

int capitalize(char *p_to, char *p_from, int *len)
{ 
    char ch;
    int i;
	for(i=0;i<100;i++){	
     		ch=*p_from;
     		if(ch=='\0') break;
        	ch = ch - ('a'-'A');
        	*p_to=ch;
		p_to++;
        	p_from++;
        	(*len)++;
	}
return 1;
}			
int main()
{
	char buffer[100];
	int len=0;
	capitalize(buffer, "teststring", &len);
	printf("%s,%d\n",buffer,len);
}



