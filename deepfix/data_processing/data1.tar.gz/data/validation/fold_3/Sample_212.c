#include <stdio.h>

int capitalize(char *p_to, char *p_from, int *len ) 
{
char ch;
		while(1){
		ch = *p_from;
		if(ch>='a' && ch<='z')
		{
			ch = ch - ('a'-'A');
			*len = *len + 1;
		}

		*p_to = ch;
		if(ch == '\0')break;
		
		p_from = p_from + 1;
		p_to = p_to + 1;

		}
		
return 1;

}




int main(){
char buffer[100];
int len;
len = 0;
capitalize(buffer, "test string", &len );
printf(buffer);
printf("\n%d�̕�����ϊ����܂����B",len);

}
