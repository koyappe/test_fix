


#include<stdio.h>

struct record{
	int eng;
	int math;
	int phy;
};

struct record database[20]=
  { {27,54,49},
  {55,99,56},
  {96,81,100},
  {28,80,90},
  {22,57,31},
  {94,75,73},
  {60,59,67},
  {64,79,30},
  {29,77,57},
  {62,47,95},
  {93,23,23},
  {73,63,59},
  {34,57,27},
  {51,62,86},
  {73,76,28},
  {72,96,64},
  {24,76,73},
  {98,91,88},
  {70,78,80},
  {60,98,95}
};

struct query{
	char f1;
	char op;
	char f2;
};

float calc_mean(struct record p){
	float i;
	i=(p.eng+p.math+p.phy)/3.0;
	return i;
}

int get_field(char f,struct record q){
	switch(f){
		case'e':return q.eng;
		case'm':return q.math;
		case'p':return q.phy;
		default:printf("eng����͂��܂�");
		return q.eng;
	}
}

int check_record(struct query p,struct record q){
	switch(p.op){
		case'>':if(get_field(p.f1,q)>get_field(p.f2,q)){
			return 1;
		}else{
			return 0;
		}
		case'<':if(get_field(p.f1,q)<get_field(p.f2,q)){
			return 1;
		}else{
			return 0;
		}
		case'=':if(get_field(p.f1,q)==get_field(p.f2,q)){
			return 1;
		}else{
			return 0;
		}
	}
}

int main(){
	while(1){
		int i,y;
		i=0;
		y=0;
		struct query q;
		scanf("%c %c %c",&q.f1,&q.op,&q.f2);
		fflush(stdin);
		while(i<20){
			y=check_record(q,database[i]);
			if(y==1){
				printf("%d�l��\n",i+1);
				i++;
			}else{
				i++;
			}
		}
	}
}

