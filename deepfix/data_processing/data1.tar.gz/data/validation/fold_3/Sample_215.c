#include<stdio.h>

int capitalize(char *p_to, char *p_from)
{
 char ch;	
   while(1)	
    {
      ch=*p_from;	
      if(('a'<=ch)&&(ch<='z'))ch = ch-('a'-'A');
      *p_to=ch;	
      p_from = p_from+1;	
      p_to = p_to+1;                        
      if(ch=='\0') break;	
  }
}

int main()
{
 char buffer[100];
 int len;
 capitalize(buffer,"teststring");
 printf(buffer);
}
