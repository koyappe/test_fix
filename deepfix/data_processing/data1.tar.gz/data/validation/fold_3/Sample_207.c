


#include <stdio.h>

struct record
{
		int eng;
		int math;
		int phy;
};

struct query
{
		char f1, op, f2;
};

struct record database[20] =
{ 
		{27,54,49},
  		{55,99,56},
  		{96,81,100},
		{28,80,90},
  		{22,57,31},
		{94,75,73},
		{60,59,67},
		{64,79,30},
		{29,77,57},
		{62,47,95},
		{93,23,23},
		{73,63,59},	
		{34,57,27},
		{51,62,86},
		{73,76,28},
		{72,96,64},
		{24,76,73},
		{98,91,88},
		{70,78,80},
		{60,98,95}
};

int get_field(char a, struct record b)		
{		
		int i;
		if (a == 'e')
		return b.eng;

		else if (a == 'm')
		return b.math;

		else if (a == 'p')
		return b.phy;

		else
		printf("Error!!");	
}

int main()		
{
		int i, x;
		char a;
		struct record b;
		scanf("%c\n", &a);
		for (i=0; i<20; i++)
		{
				x = get_field(a, database[i]);
				printf("%d\n", x);
		}	
}

