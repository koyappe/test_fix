#include<stdio.h>

int capitalize(char *p_to, char *p_from, int *len)
{
    int i;
    char ch;
    for(i=0;i<20;i++)
    {
        ch=*p_from;
        if(ch=='\0')break;
        if(ch>='a'&&ch<='z')
        {
            ch = ch - ('a'-'A');
            *p_to=ch;
            p_to++;
            p_from++;
            (*len)++;         
        }
        else
        {
            p_to++;
            p_from++;
        } 
    }
}
int main()
{
    char buffer[100];
    int len=0;
    capitalize(buffer, " teststring ", &len);
    printf("%s,%d\n",buffer,len);
}

