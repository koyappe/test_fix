
#include<stdio.h>

int capitalize(char *p_to, char *p_from, int *len)
{
		char ch;
		int count=1;
		while(1)
		{
         			ch=*p_from;
				if(ch=='\0')
				{
						*p_to=ch;
						break;
				}
				else 
				{
						if (('a' <= ch) && (ch <= 'z')) 
						ch = ch - ('a'-'A');
						*p_to=ch;
						*len=count++;
						p_from++;
						p_to++;
				}
		}
		return 1;
}

int main()
{
		char buffer[100];
		int len;
		capitalize(buffer, "teststring", &len);
		printf(buffer);
		printf("\n�ϊ�����������̒���=%d",len);
		return 0;
}
