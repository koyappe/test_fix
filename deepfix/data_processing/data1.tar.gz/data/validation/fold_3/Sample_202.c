#include<stdio.h>
#include<stdlib.h>
#include<time.h>
struct record{
	int eng,math,phy;
};
struct record database[20] =
 { {27,54,49},
  {55,99,56},
  {96,81,100},
  {28,80,90},
  {22,57,31},
  {94,75,73},
  {60,59,67},
  {64,79,30},
  {29,77,57},
  {62,47,95},
  {93,23,23},
  {73,63,59},
  {34,57,27},
  {51,62,86},
  {73,76,28},
  {72,96,64},
  {24,76,73},
  {98,91,88},
  {70,78,80},
  {60,98,95}
};
float calc_mean(struct record aaa){
	float sum=0;
	sum=(aaa.eng+aaa.math+aaa.phy)/3;
	return sum;
}
struct query{
	char f1,op,f2;
};
int get_field(char c,struct record ccc){
	if(c=='e'){
		return ccc.eng;
	}
	else if(c=='m'){
		return ccc.math;
	}
	else if(c=='p'){
		return ccc.phy;
	}
	else{
		printf("�G���[\n");
	}
}
int check_record(struct record aaa,struct query bbb){
   int left = get_field(bbb.f1,aaa);
   int right = get_field(bbb.f2,aaa);
	if(bbb.op=='>'){
		if(left>right){
			return 1;
		}
		else{ 
			return 0;
		}
	}
	else if(bbb.op=='='){
		if(left==right){
			return 1;
		}
		else{ 
			return 0;
		}
	}
	else if(bbb.op=='<'){
		if(left<right){
			return 1;
	}
		else{ 
			return 0;
		}
	}

}
int main(){
	while(1){
		struct query q;
		scanf("%c %c %c",&q.f1,&q.op,&q.f2);
		fflush(stdin);
		int i,z;
		for(i=0;i<20;i++){
			z=check_record(database[i],q);
			if(z==1){
				printf("�w�Дԍ�%d\n",i+1);
			}
		}
	}
}
