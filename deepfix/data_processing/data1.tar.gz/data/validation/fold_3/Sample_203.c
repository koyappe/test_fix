#include<stdio.h>
#include<stdlib.h>
#include<time.h>

struct record
{
 int eng;
 int math;
 int phy;
};

struct record database[20] = 
 { {27,54,49},
  {55,99,56},
  {96,81,100},
  {28,80,90},
  {22,57,31},
  {94,75,73},
  {60,59,67},
  {64,79,30},
  {29,77,57},
  {62,47,95},
  {93,23,23},
  {73,63,59},
  {34,57,27},
  {51,62,86},
  {73,76,28},
  {72,96,64},
  {24,76,73},
  {98,91,88},
  {70,78,80},
  {60,98,95}
};

float calc_mean(struct record x)
{
     float  a ;
     a=0;
     a =(x.eng+x.math+x.phy)/3 ;
     return a ;
}

struct query
{
   char f1;
   char op;
   char f2;
};

int get_field(char k, struct record h)
{
  switch(k)
   {
    case'e':return h.eng;
    case'm':return h.math;
    case'p':return h.phy;
    default:printf("e,m,p�ȊO����͂��Ȃ��ł�������\n");
   }
}

int check_record(struct record h, struct query j)
{
  if(j.op == '=')
    {
      if(get_field(j.f1,h)==get_field(j.f2,h))
     {
        return 1;
      }
   }
  else if(j.op == '<')
    {
      if(get_field(j.f1,h)<get_field(j.f2,h))
        {
          return 1;
       }
     }
  else if(j.op == '>')
    {
      if(get_field(j.f1,h)>get_field(j.f2,h))
        {
          return 1;
       }
     }
  return 0;
}

int main()
{
  int i;
  int s;
  struct query q;
  scanf("%c %c %c",&q.f1,&q.op,&q.f2);
  for(i=0;i<20;i++)
     {
       s=check_record(database[i],q);
      if(s == 1)
      {
         printf("�w�Дԍ�%d\n",i);
         }
      }
}
