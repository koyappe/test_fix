
#include <stdio.h>

struct record{
	int eng;
	int math;
	int phy;
};

struct query{
	char f1;
	char op;
	char f2;
};

struct record database[20]=
{ {27,54,49},
  {55,99,56},
  {96,81,100},
  {28,80,90},
  {22,57,31},
  {94,75,73},
  {60,59,67},
  {64,79,30},
  {29,77,57},
  {62,47,95},
  {93,23,23},
  {73,63,59},
  {34,57,27},
  {51,62,86},
  {73,76,28},
  {72,96,64},
  {24,76,73},
  {98,91,88},
  {70,78,80},
  {60,98,95}
};

int get_field(char f, struct record p2){  
	if(f=='e'){
		return p2.eng;
	}
	else if(f=='m'){
		return p2.math;
	}
	else if(f=='p'){
		return p2.phy;
	}
}

int check_record(struct record p1, struct query q1){ 
	int l,r;
	l=get_field(q1.f1, p1);
	r=get_field(q1.f2, p1);
	if(q1.op=='>'){
		if(l > r){
			return 1;
		}
		else{
			return 0;
		}
	}
	else if(q1.op=='<'){
		if(l < r){
			return 1;
		}
		else{
			return 0;
		}
	}
	else if(q1.op=='='){
		if(l == r){
			return 1;
		}
		else{
			return 0;
		}
	}
}

int main(){
	int val,i;
	struct query q;
	while(1){
		scanf("%c %c %c", &q.f1, &q.op, &q.f2);
		fflush(stdin);
		for(i=0;i<20;i++){
			val = check_record(database[i], q);
			if(val==1){
				printf("%d ",i+1);
			}
		}
		printf("\n");
	}
}
