#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int i;
float ave;

struct record
{
	int eng,math,phy;
};

struct record database[20] =
 { {27,54,49},
  {55,99,56},
  {96,81,100},
  {28,80,90},
  {22,57,31},
  {94,75,73},
  {60,59,67},
  {64,79,30},
  {29,77,57},
  {62,47,95},
  {93,23,23},
  {73,63,59},
  {34,57,27},
  {51,62,86},
  {73,76,28},
  {72,96,64},
  {24,76,73},
  {98,91,88},
  {70,78,80},
  {60,98,95}
};

float calc_mean(struct record i){
	ave = (i.eng + i.math + i.phy)/3;
	return ave;
}



struct query{
	char f1;
	char op;
	char f2;
};

int get_field(char c,struct record r/*char c�ƍ\����record r���󂯎��*/){
	if(c == 'e'){ 		
		return r.eng;
	}else if(c == 'm'){	
		return r.math;
	}else if(c == 'p'){	
		return r.phy;
	}else{
	printf("please input e,m,p only.");
	}
}

int check_record(struct record r,struct query q/*�\����record r�ƍ\����query q���󂯎��*/){
	int fc1,fc2,j;
	j = 0;
	fc1 = get_field(q.f1,r);
	fc2 = get_field(q.f2,r);
	j = fc1 - fc2;
	if(q.op == '<'){
		if(j<0){
		return 1;
		}else{
		return 0;
		}
	}else if(q.op == '='){
					if(j=0){
					return 1;
					}else{
					return 0;
					}
				}else if(q.op == '>'){
								if(j>0){
								return 1;
								}else{
								return 0;
								}
							}else{
							printf("please input e,m,p <,=,> only.");
							}


}

int main(){
	struct query q;
	char c;
	while (1){
		printf("e m p ��< = > ��p���Č������������肵�Ă��������B\n");
		scanf("%c %c %c", &q.f1, &q.op, &q.f2);
		fflush(stdin);
		
		int x;
		for(i=0;i<20;i++){
			x = check_record(database[i],q);
			if(x==1){
printf("�w�Дԍ�%d ( %d , %d , %d )\n",i,database[i].eng,database[i].math,database[i].phy);
			}		
		}
	}
}
