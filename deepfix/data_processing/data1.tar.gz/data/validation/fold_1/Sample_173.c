
#include <stdio.h>
#define N 20

struct query					
{
	char f1,op,f2;
};

struct record					
{
	int eng,math,phy;
};

struct record database[N] =		
 { {27,54,49},
  {55,99,56},
  {96,81,100},
  {28,80,90},
  {22,57,31},
  {94,75,73},
  {60,59,67},
  {64,79,30},
  {29,77,57},
  {62,47,95},
  {93,23,23},
  {73,63,59},
  {34,57,27},
  {51,62,86},
  {73,76,28},
  {72,96,64},
  {24,76,73},
  {98,91,88},
  {70,78,80},
  {60,98,95}
};

float calc_main(struct record d)
{
	float sum=0;
	sum = d.eng + d.math + d.phy;

	return sum;

int get_field(char c, struct record d)
{
	switch (c){
		case 'e':
			return d.eng;
		case 'm':
			return d.math;
		case 'p':
			return d.phy;
		default:
			printf("ERROR! [e]eng [m]math [p]phy\n");
			return -1;
	}

}


int check_record(struct query q, struct record d)
{
	int i,val1,val2;
	val1 = get_field(q.f1,d);
	val2 = get_field(q.f2,d);

	if(val1 < 0 || val2 < 0) return -1;

	switch (q.op){										
		case '>':
			if(val1 > val2) return 1;
			else return 0;
		case '<':
			if(val1 < val2) return 1;
			else return 0;
		case '=':
			if(val1 == val2) return 1;
			else return 0;
		default:										
			printf("ERROR! [>] [<] [=]\n");
			return -1;
	}

	return 0;
}

int main()
{
	int i,val;
	struct query q;
	while(1)
	{
		scanf("%c %c %c",&(q.f1),&(q.op),&(q.f2));		
		for(i=0;i<N;i++)								
		{
			val = check_record(q,database[i]);
			if(val==1) printf("[%d]",i);				
			else if(val<0) break;						
		}
		printf("\n");
		fflush(stdin);
	}
}
