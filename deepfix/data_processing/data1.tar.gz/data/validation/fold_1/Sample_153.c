
#include<stdio.h>

int stack[5];
int i=0;

int push(int data)
{
if(i>4)
 {
  return -1;
 }
 else
{
 stack[i]=data;
 i++;	
 return 1;
 }
}
int pop()
{
 if(i<1)
 {
  return -1;
 }
 else
 {
	 i--;
 return stack[i];
 }
}

int main()
{
	int data;

	while(1){
		scanf("%d", &data);
		if (data >= 0)
		{
			int val;
			val = push(data);
     	if (val < 0) printf("can not push\n");	
     	else printf("%d is pushed\n", data);
  		} 
  		else 
   	{
     	data = pop();
    	 if (data < 0) printf("can not pop\n");
   	  else printf("%d is popped\n", data);
   	}
	}
}
