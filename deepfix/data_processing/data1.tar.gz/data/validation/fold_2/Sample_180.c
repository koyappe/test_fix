#include<stdio.h>

struct test{
int eng;
int math; 
int phy;
};
struct test database[20] =
 { {27,54,49},
  {55,99,56},
  {96,81,100},
  {28,80,90},
  {22,57,31},
  {94,75,73},
  {60,59,67},
  {64,79,30},
  {29,77,57},
  {62,47,95},
  {93,23,23},
  {73,63,59},
  {34,57,27},
  {51,62,86},
  {73,76,28},
  {72,96,64},
  {24,76,73},
  {98,91,88},
  {70,78,80},
  {60,98,95}
};

struct query{
	char f1;
	char op;
	char f2;
};

int get_field(struct test s,char j){

	int a=-1;
	if(j=='e'){
		a = s.eng;
	}
	else{
		if(j=='m'){
			a=s.math;
		}
		else{
			if(j=='p'){
				a=s.phy;
			}		
		}
	}
	return a;

}

int check_record(struct test q,struct query d){
	int a=-1;
	int lef=get_field(q,d.f1);
	int rig=get_field(q,d.f2);
	if(lef==-1&&rig==-1){
	}
	else{
		if(d.op=='<'){
			if(lef<rig){
				a=1;
			}
		}
		if(d.op=='='){
			if(lef==rig){
				a=1;
			}
		}
		if(d.op=='>'){
			if(lef>rig){
				a=1;
			}
		}
	}
	return a;
}

int main()
{
	int i,j;
	struct query q;
	while(1){
		scanf("%c %c %c",&q.f1,&q.op,&q.f2);
        printf("�Y������w�Дԍ���\n");
        for(i=0;i<20;i++){
          j=check_record(database[i],q);
          if(j==1){
              printf("�@�@�@�@�@�@�@�@�@%d\n",i+1);
          }
	     }
    printf("�ł��B\n");	
	}
}















