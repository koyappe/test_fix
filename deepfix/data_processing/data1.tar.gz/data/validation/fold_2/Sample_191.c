#include<stdio.h>

struct record{	
	int eng;	
	int math;	   
	int phy;
};


struct query{		  
	char f1;
	char op;
	char f2;
};

struct record database[20] =
{ 
{27,54,49},
  {55,99,56},
  {96,81,100},
  {28,80,90},
  {22,57,31},
  {94,75,73},
  {60,59,67},
  {64,79,30},
  {29,77,57},
  {62,47,95},
  {93,23,23},
  {73,63,59},
  {34,57,27},
  {51,62,86},
  {73,76,28},
  {72,96,64},
  {24,76,73},
  {98,91,88},
  {70,78,80},
  {60,98,95}
};



int get_field(char x,struct record y)	
{
	if(x=='e')
	return y.eng;			
	if(x=='m')
	return y.math;			
	if(x=='p')
	return y.phy;			
}

int check_record(struct query q,struct record r){
  int a=0;
  int x,y;
  x=get_field(q.f1,r);
	y=get_field(q.f2,r);
	switch(q.op){
		case'>':
			if(x>y){
			a=1;
       }
			break;
		case'=':
       if(x==y){
			a=1;
			}
			break;
		case'<':
			if(x<y){
			a=1;
			}
			break;
		default:				
			break;
	}
return a;
}

int main()
{
	int b;
	int i;
	while(1){					
	  struct query q;					
      scanf("%c %c %c",&q.f1,&q.op,&q.f2);
	  printf("�Y���҂�\n");				
    for(i=0;i<20;i++){
		  b=check_record(q,database[i]);		
      if(b==1){						
       printf("�@�@�@�@%d\n",i+1);		
      } 
	  } 
  printf("�@�@�@�@�Ԃł��B\n"); 				
	}
}

