#include<stdio.h>

struct record{
  int eng,math,phy;
};

struct query{
  char f1,op,f2;
};


struct record database[20]={
  {27,54,49},
  {55,99,56},
  {96,81,100},
  {28,80,90},
  {22,57,31},
  {94,75,73},
  {60,59,67},
  {64,79,30},
  {29,77,57},
  {62,47,95},
  {93,23,23},
  {73,63,59},
  {34,57,27},
  {51,62,86},
  {73,76,28},
  {72,96,64},
  {24,76,73},
  {98,91,88},
  {70,78,80},
  {60,98,95}
};
int get_field(struct record q2,char x){
  int a=-1;
  switch(x){
    case'e':
      a=q2.eng;
      break;
    case'm':
      a=q2.math;
      break;
    case'p':
      a=q2.phy;
      break;
    default:
      printf("error\n");
      break;
  }
  return a;
}

int check_record(struct record q1,struct query qqq){
  int a;
  int l = get_field(q1,qqq.f1);//f1��get_field�ɑ���A�Ԃ��Ă����l��l�ɑ��
  int r = get_field(q1,qqq.f2);//f2��get_field�ɑ���A�Ԃ��Ă����l��r�ɑ��
  switch(qqq.op){
     case'>':
        if(l>r){
           a=1;
        }
        else{
           a=0;
        }
        break;
     case'<':
        if(l<r){
           a=1;
        }
        else{
           a=0;
        }
        break;
     case'=':
        if(l==r){
           a=1;
        }
        else{
           a=0;
        }
        break;
     default:
        printf("error\n");
  }
  return a;
}

int main(){
     while(1){
          int i,j;
          struct query q;
          scanf("%c %c %c",&q.f1,&q.op,&q.f2);
          fflush(stdin);
          printf("�Y������w�Дԍ�\n");
          for(i=0;i<20;i++){
                j=check_record(database[i],q);
                if(j==1){//���͂��ꂽ�f�[�^�ɓK�����Ă��邩���f
                     printf("�@�@�@�@�@�@�@�@%d\n",i+1);
                }
          }
     }
}

