#include <stdio.h>
struct record{
	  int eng,math,phy;
};

struct record database[20] =
 { {27,54,49},
  {55,99,56},
  {96,81,100},
  {28,80,90},
  {22,57,31},
  {94,75,73},
  {60,59,67},	
  {64,79,30},
  {29,77,57},
  {62,47,95},
  {93,23,23},
  {73,63,59},
  {34,57,27},
  {51,62,86},
  {73,76,28},
  {72,96,64},
  {24,76,73},
  {98,91,88},
  {70,78,80},
  {60,98,95}
};

struct query{
	  char f1,op,f2;
}; 

int get_field(char f,struct record p){
int b;
	switch(f){
		case 'e':b=p.eng;
		break;
		case 'm':b=p.math;
		break;
		case 'p':b=p.phy;
		break;
		default:printf("�����ȕ����ł��B\n");
		b=0;
		break;
	}
	return  b;
}

int check_record(struct record p,struct query q){
	switch(q.op){
		case '<':if(get_field(q.f1,p)<get_field(q.f2,p)){
			return 1;
				}else{
			return 0;
				}
		case '>':if(get_field(q.f1,p)>get_field(q.f2,p)){
			return 1;
				}else{
			return 0;
				}
		case '=':if(get_field(q.f1,p)==get_field(q.f2,p)){
			return 1;
				}else{
			return 0;
				}
	}
}

int main(){
	  int i,a;
	  struct query q;
	while(1){
		i=0;
		scanf("%c %c %c",&q.f1,&q.op,&q.f2);
		fflush(stdin);
		  while(i<20){
			a=check_record(database[i],q);
			  if(a==1){
				  printf("�w�Дԍ�%d��\n",i+1);
							}
			i++;
		}
	}
	    return 0;
}

