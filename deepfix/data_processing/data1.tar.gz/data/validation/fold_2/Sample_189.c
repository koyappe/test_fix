#include <stdio.h>

struct record{
	int eng;
	int math;
	int phy;
};

struct record database[20] =
 { {27,54,49},
  {55,99,56},
  {96,81,100},
  {28,80,90},
  {22,57,31},
  {94,75,73},
  {60,59,67},	
  {64,79,30},
  {29,77,57},
  {62,47,95},
  {93,23,23},
  {73,63,59},
  {34,57,27},
  {51,62,86},
  {73,76,28},
  {72,96,64},
  {24,76,73},
  {98,91,88},
  {70,78,80},
  {60,98,95}
};

struct query{
	char f1;
	char op;
	char f2;
};

int get_field(char f,struct record p){
	int get;
	switch(f){
		case 'e':get=p.eng;
		break;
		case 'm':get=p.math;
		break;
		case 'p':get=p.phy;
		break;
		default:printf("�����ȕ����Ȃ̂ŉp��̒l��Ԃ��܂�\n");
		get=p.eng;
		break;
	}
	return get;
}
int check_record(struct record p,struct query q){
	switch(q.op){
		case '<':if(get_field(q.f1,p)<get_field(q.f2,p)){
						return 1;
						}else{
						return 0;
						}
		case '>':if(get_field(q.f1,p)>get_field(q.f2,p)){
						return 1;
						}else{
						return 0;
						}
		case '=':if(get_field(q.f1,p)==get_field(q.f2,p)){
						return 1;
						}else{
						return 0;
						}
		default:printf("�����ȕ����Ȃ̂œ������s���܂�\n");
			if(get_field(q.f1,p)==get_field(q.f2,p)){
				return 1;
				}else{
				return 0;
			}
	}
}

int main(){
	int i,ans;
	struct query q;
	while(1){
		i=0;
		scanf("%c %c %c",&q.f1,&q.op,&q.f2);
		fflush(stdin);
		while(i<20){
			ans=check_record(database[i],q);
			switch(ans){
				case 1:printf("�o�Ȕԍ�%d��\n",i+1);
								break;
				case 0:break;
			}
			i++;
		}
	}
	return 0;
}

