#include<stdio.h>

struct record
{
	int eng;
	int math;
	int phy;
};

struct record database[20]=
{
	{27,54,49},
	{55,99,56},
  	{96,81,100},
  	{28,80,90},
  	{22,57,31},
  	{94,75,73},
  	{60,59,67},
  	{64,79,30},
  	{29,77,57},
  	{62,47,95},
  	{93,23,23},
  	{73,63,59},
  	{34,57,27},
  	{51,62,86},
  	{73,76,28},
  	{72,96,64},
  	{24,76,73},
  	{98,91,88},
  	{70,78,80},
  	{60,98,95}
};

int get_field(char c,struct record s)
{
	if(c=='e')
	{
		return s.eng;
	}
	else if(c=='m')
	{
		return s.math;
	}
	else if(c=='p')
	{
		return s.phy;
	}
	else
	{
		return 0;
	}
}

int main()
{
	int i;
	char c;
	scanf("%c",&c);
	for(i=0;i<20;i++)
	{
printf("%d\n",get_field(c,database[i]));
	}
}

