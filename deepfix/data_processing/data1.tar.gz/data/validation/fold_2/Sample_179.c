

#include<stdio.h>

struct record
{
 int eng,math,phy;
};

 struct record database[20] =
 { {27,54,49},
  {55,99,56},
  {96,81,100},
  {28,80,90},
  {22,57,31},
  {94,75,73},
  {60,59,67},
  {64,79,30},
  {29,77,57},
  {62,47,95},
  {93,23,23},
  {73,63,59},
  {34,57,27},
  {51,62,86},
  {73,76,28},
  {72,96,64},
  {24,76,73},
  {98,91,88},
  {70,78,80},
  {60,98,95}
};
float calc_mean(struct record i)
{
 
 float a;
 
 a=(i.eng+i.math+i.phy)/3;
 return a;
}

struct query
{
 char f1,op,f2;
};

int get_field(char c,struct record p)
{
    if(c=='e')
  {
   return p.eng;
  }
    else if(c=='m')
  {
   return p.math;
  }
    else if(c=='p')
  {
    return p.phy;
  }
    else
  {
   printf("error"); 
   return 0;
  }
}

int main()
{
 char m;
 scanf("%c",&m);
 int i;
  for(i=0;i<20;i++)
  {
     int k;
     k=get_field(m,database[i]);
     printf("%d\n",k);
  }
}
