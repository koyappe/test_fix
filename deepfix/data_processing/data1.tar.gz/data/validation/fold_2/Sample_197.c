struct record
{
int eng, math, phy;
};


struct record database[20] = 
 { {27,54,49},
  {55,99,56},
  {96,81,100},
  {28,80,90},
  {22,57,31},
  {94,75,73},
  {60,59,67},
  {64,79,30},
  {29,77,57},
  {62,47,95},
  {93,23,23},
  {73,63,59},
  {34,57,27},
  {51,62,86},
  {73,76,28},
  {72,96,64},
  {24,76,73},
  {98,91,88},
  {70,78,80},
  {60,98,95}
};


struct query
{
char f1, op, f2;
};


int get_field(struct record i,char qf)
{
	if(qf == 'e')return i.eng;
	else if(qf == 'm')return i.math;
	else if(qf == 'p')return i.phy;
}


int check_record(struct record i,struct query q)
{	
	int f1, f2;
	int sa = 0;

	f1 = get_field(i,q.f1);
	f2 = get_field(i,q.f2);
	sa = f1 - f2;
	if(q.op == '=')
	{
		if(sa == 0)return 1;
		else return 0;
	}
	if(q.op == '<')
	{
		if(sa < 0)return 1;
		else return 0;
	}
	if(q.op == '>')
	{
		if(sa > 0)return 1;
		else return 0;
	}
}



int main()
{
int i, x;
struct query q;

	scanf("%c %c %c",&q.f1,&q.op,&q.f2);
	for(i = 0;i<20;i++)
		{
			x = check_record(database[i],q);
			if(x == 1) printf("�w�Дԍ�:%d  eng:%d math:%d phy:%d \n",i,database[i].eng,database[i].math,database[i].phy);
		}
}
