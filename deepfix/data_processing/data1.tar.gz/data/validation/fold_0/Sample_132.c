
#include <stdio.h>
#define N 5

int stack[N];
int stack_pointer = -1;

int push(int data)
{
	if(stack_pointer>=N-1) return -1;
	else{
		stack_pointer++;			
		stack[stack_pointer] = data; 
		return 0;
	}
}


int pop()
{
	int popdata;
	if(stack_pointer<0) return -1;
	else{
		popdata = stack[stack_pointer];
		stack_pointer--;			
		return popdata;
	}
	
}

int main()
{
	int data;

	while(1){
	        scanf("%d", &data);
		if (data >= 0) {
			int val;				
			val = push(data);
			if (val < 0) printf("can not push\n");	
			else printf("%d is pushed\n", data);	
	        } else {
			data = pop();
			if (data < 0) printf("can not pop\n");	
			else printf("%d is popped\n", data);	
		}
	}
}

