#include <stdio.h>

int stack[5];	
int push_pointer=0;
int pop_pointer=0;
int push_counter=0;
int pop_counter=0;

int push(int data)
{
	int x;
		stack[push_pointer]=data;
		push_pointer++;
		if(push_pointer==5){
			push_pointer=0;
			push_counter++;
		}
		x=1;
return x;
}

int pop()
{
	int y;
	if(pop_counter<push_counter){
		y=stack[pop_pointer];
		pop_pointer++;
		if(pop_pointer==5){
			pop_pointer=0;
			pop_counter++;
		}
	}else if(pop_pointer<push_pointer){
		y=stack[pop_pointer];
		pop_pointer++;
		if(pop_pointer==5){
			pop_pointer=0;
			pop_counter++;
		}
	}else{
		y=-1;
	}
	return y;
}

int main()
{
	int data;

	while(1){
	        scanf("%d", &data);
		if (data >= 0) {
			int val;
			val = push(data);
			if (val < 0) printf("can not push\n");
			else printf("%d is pushed\n", data);
	        } else {
			data = pop();
			if (data < 0) printf("can not pop\n");
			else printf("%d is popped\n", data);
		}
	}
return 0;
}
