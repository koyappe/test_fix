
#include <stdio.h>

int stack[10];
int stack_pointer=0;

int push(int data){  
	if(stack_pointer < 10){  
		stack_pointer++;
		stack[stack_pointer] = data;
		return 1;
	}
	else{
		return -1;
	}
}

int pop(){  
	int pop_data;
	if(stack_pointer > 0){  
		pop_data = stack[stack_pointer];
		stack_pointer--;
		return pop_data;
	}
	else{
		return -1;
	}
}

int stackPrint()  
{
    int i;
    printf("stack [");
    for(i = 0; i < stack_pointer + 1; i++){
		printf("%3d", stack[i]);
    }
    printf("]\n");
	return 0;
}


int main(){
	int data;
	while(1){
		scanf("%d", &data);
		if(data >= 0){
			int val;
			val = push(data);
			if (val < 0){
				printf("can not push\n");
			}
			else{
				printf("%d is pushed\n", data);
				stackPrint();
			}
		}
		else{
			data = pop();
			if (data < 0){
				printf("can not pop\n");
			}
			else{
				printf("%d is popped\n", data);
				stackPrint();
			}
		}
	}
}


