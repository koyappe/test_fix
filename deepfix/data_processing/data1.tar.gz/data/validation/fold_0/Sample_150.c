#include <stdio.h>

int stack[5];
int sp;         

int push (int data)
{
	stack[sp] = data;
	sp = sp + 1;
	if(sp > 5)return -1;   
	return data;			
}
int pop()
{
	int data;
	sp = sp -1;				
	if(sp < 0)return -1;
	data = stack[sp];
	return data;
}
int main()
{
	int data;

			while(1)
			{
	      
			 	scanf("%d", &data);
				fflush(stdin); 

				 	if (data >= 0)
					{
						int val;
						val = push(data);

						if (val < 0) printf("can not push\n");
					    	else printf("%d is pushed\n", data);
					}
					else 
					{
						data = pop();

						if (data < 0) printf("can not pop\n");
						else printf("%d is popped\n", data);
					}
			}
}

#include <stdio.h>

int queue[5];
int q_tail = 0;
int q_head = 0;

int enqueue(int date)
{
			if(q_tail == 5)
			{
				printf("overflow\n");
				return -1;
			}
	queue[q_tail] = date;
	q_tail ++;
	return 0;
}

int dequeue()
{
	int val;
			if(q_tail == q_head)
			{
				printf("underflow\n");
				return -1;
			}
	val = queue[q_head];
	q_head++;
	return val;
}

int main()
{
	int data;

			while(1)
			{
				fflush(stdin);
			 	scanf("%d", &data);
			 	if (data >= 0){
						int val;
						val = enqueue(data);

						if (val < 0) printf("can not push\n");
					    else printf("%d is pushed\n", data);
					}
					else 
					{
						data = dequeue();

						if (data < 0) printf("can not pop\n");
						else printf("%d is popped\n", data);
					}
			}
}
