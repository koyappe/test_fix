
#include <stdio.h>

int stack[10];	
int stack_pointer=0;

int push(int data)
{
	if(stack_pointer>9){
		return -1;
	}

	stack[stack_pointer]=data;
	stack_pointer=stack_pointer+1;
	return data;
}

int pop()
{
	int data;
	if(stack_pointer<0){
		return -1;
	}
	data=stack[stack_pointer-1];
	stack_pointer=stack_pointer-1;
	return data;
}

int main()
{
	int data;

	while(1){
	        scanf("%d", &data);
		if (data >= 0) {
			int val;
			val = push(data);
			if (val < 0) printf("can not push\n");
			else printf("%d is pushed\n", data);
	        } else {
			data = pop();
			if (data < 0) printf("can not pop\n");
			else printf("%d is popped\n", data);
		}
	}
}


