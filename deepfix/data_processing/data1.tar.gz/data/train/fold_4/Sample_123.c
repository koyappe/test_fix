#include <stdio.h>

int stack[10];	
int stack_pointer=0;

int push(int data)	
{
	int j;	
	stack[stack_pointer]=data;	
	if(stack_pointer<9){	
		j=1;
	}
	else{
		j=-1;
	}
	stack_pointer++;		
	return j;		
}

int pop()
{ 
	int i=0;
	stack_pointer--;		
	if(stack_pointer>=0){	
		i=stack[stack_pointer];	

	}
	else{		
	i=-1;
	}
	return i;		
}

int main()
{
	int data;

	while(1){
	        scanf("%d", &data);	
		if (data >= 0) {		
			int val;
			val = push(data);		
			if (val < 0) printf("can not push\n");	
			else printf("%d is pushed\n", data);		
	        } else {
			data = pop();	// pop��data�󂯎��
			if (data < 0) printf("can not pop\n");	
			else printf("%d is popped\n", data);	
		}
	}
}

