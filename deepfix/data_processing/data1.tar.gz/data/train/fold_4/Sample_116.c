
#include<stdio.h>
int fact(int n)
{
	int f=1;
	int i;
	for (i=1;i<=n;i++)
	{
	f=f*i;

	}
	printf("%d\n",f);
	return f;
}

float f(int n)
{
		float sum=0.0;
		int k;
		for(k=0;k<=n;k++)
	{
		sum = sum + 1.0/fact(k);
		printf("%f\n",sum);
	}
	return sum;
}


int main()
{
	printf("%f\n",f(10));
}

#include<stdio.h>


int fact(int n)
{
	int f=1;
	int i;
	for (i=1;i<=n;i++)
	{
	f=f*i;
	}
	printf("%d\n",f);
	return f;
}

float f(int n)
{
		float sum=0.0;
		int k;
		for(k=0;k<=n;k++)
	{
		if(1.0/fact(k)<0.00001)
		{
			return sum;
		}
		sum = sum + 1.0/fact(k);
		printf("%f\n",sum);
	}
	return sum;
}


int main()
{
	printf("%f\n",f(1000));
	return 0;
}

