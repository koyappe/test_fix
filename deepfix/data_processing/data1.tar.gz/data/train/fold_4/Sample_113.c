
#include<stdio.h>

int fact(int n)				
{
	int i,f;				
	f=1;				
	for(i=1;i<=n;i++)		
	{
		f=f*i;			
	}
return f;				
}

float ff(int k)				
{	
	float sum;				
	int n;					
	sum=0;					
	for(n=0;n<k+1;n++)			
	{
		sum=sum+1.0/fact(n);		
	}
return sum;					
}

int main()
{
	printf("%f",ff(10));			
}
