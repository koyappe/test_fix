
#include <stdio.h>
 int fact(int n)  
{
  int f;
  int i;
  f=1;
  for(i=1;i<=n;i++)
 {
   f=f*i;
 }
 return f; 

}float f(int k)  
{
  float answer=0;
  int i;
  for(i=0;i<=k;i++)
  answer=answer+1.0/fact(i); 
return answer; 
}
 int main()
{
  printf("%f",f(10));
}



