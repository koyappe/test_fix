
#include<stdio.h>
float fact(n){			
	int i;			
	float x;			
	x=1.0;			
	for(i=1;i<=n;i++)	
		x=x*i; 		
	return x;		
}

float f(k){			
	int n;			
	float y;			
	y=0.0;			
	for(n=0;n<k;n++)		
		y=y+(1.0/fact(n));		
	return y;		
}

int main(){
	int k;			
	float z;			
	k=10;		
	z=f(k);			
	printf("���̓�����%f\n",z);		
}

