
#include<stdio.h>


int fact(int n)
{ 
   int f,i;
   f=1;
   for(i=1;i<=n;i++)
     {
       f=f*i;
     }
   return f;  
 }
float f(int k)
 {
  int n;
  float sum;
  n=0;
  sum = 0.0;
  for(n=0;n<k;n++)
  {
      sum =sum + (1.0/fact(n));
    }
   return sum;
 }

int main()
 {
    int k;
   float x;
    k=10;
    x = f(k); 
    printf("%f\n",x);
   return 0;
 

