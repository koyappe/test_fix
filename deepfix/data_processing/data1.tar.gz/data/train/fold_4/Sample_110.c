

#include <stdio.h>


int fact (int n)	
{
    int f;
    int i;
    f = 1;
    for(i=1; i<=n; i++)	
    {
         f=f*i;
    }
    return f;
}

int main()
{
float e;
e = 0;
int n;

for(n=0; n<=10; n++)
{		
		int f = fact(n);	
		e = e + 1.0/f;
}

printf("%f\n", e);	

}		

