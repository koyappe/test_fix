
#include <stdio.h>

int i=0,k=0,val=0;
float e=0,j=0;

int fact(int n)
{
	int f,i,j;
	f=1;
	for(i=1;i<n+1;i++){
	f=f*i;
	}
	return f;
}
float f(int k)
{
	for(k=0;k<=i;k++)
		{
		val = fact(k);
		e=e+1.0/val;
		}
}

int main()
{
	scanf("%d",&i);
	j = f(i);
	printf("%d\n%f",val,e);
}

