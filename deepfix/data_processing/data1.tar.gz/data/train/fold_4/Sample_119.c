
#include<stdio.h>

int fact(int n)
{
		int f,i;
		f=1;
		for(i=1;i<=n;i++)
				{
						f=f*i;
				}
		return f;
}

int main()
{
		int i,val,n,f;
		float e;
		scanf("%d",&i);
		e=0;
		for(n=0;n<=i;n++)
				{
						val=fact(n);
						e = e + (1.0/val);
				}
		printf("%f\n",e);  /
		return 0;
}

