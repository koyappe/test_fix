#include<stdio.h>

int fact(int n)

{
	int x,y;

	x=1;
	for(y=0;y<n;y++)
	{
	x*=(n-y);
	}
 	return x;
}
float f(int k)
{
	
	float sum;
	float z;
	int i;
	for(i=0;i<=k;i++)
	{
		z=1.0/fact(i);
		sum=sum+z;
		if(z<=0.00001)break;
	}
	return sum;
}
int main()
{
	printf("%f", f(10));
	printf("%f", f(1));
	printf("%f", f(2));
	printf("%f", f(3));
}


