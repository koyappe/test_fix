
float fact(int i) 
{
	int l;
	float m=1;
	for(l=1; l<=i; l++)	
	{
		m=m*l;
	}
	return m; 
}

float f(int k)
{
	int i;
	float j=0;
	for(i=0; i<=k; i++)
	{
		j=j+1.0/fact(i); 
	}
	return j;
}

int main()
{

	int k;
	scanf("%d", &k);
	printf("%f", f(k));
	return 0;
}


float fact(int i)
{
int l;
float m=1;
for(l=1; l<=i; l++)
	{
	m=m*l;
	}
return m;
}

float f(int k)
{
int i;
float j=0;
for(i=0; i<=k; i++)
	{
	j=j+1.0/fact(i);
	}
return j;
}


