

#include <stdio.h>

int fact(int n)
{
	int i = 0;
	int kai = 1;

		if(n == 0) return 1;

		while( n > i)
		{
				i = i + 1;
				kai = kai * i;
		}

return kai;
}


float f(int k)
{
	float sum = 0;
	int 	i = 0;
	float b = 1;

		for(i = 0; i <= k; i++)
			{
				if(b < 0.00001)break;
					b = 1.0/fact(i);
					sum = sum + b;
			}

return sum;
}


float main()
{
	printf("%f\n",f(1));
	printf("%f\n",f(2));
	printf("%f\n",f(3));
	printf("%f\n",f(10));
	printf("%f\n",f(100));
	printf("%f\n",f(1000));
}


