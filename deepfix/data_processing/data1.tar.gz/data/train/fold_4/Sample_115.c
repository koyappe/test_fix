
#include <stdio.h>

int fact(int n)
{
int f;
int i;
f=1;
for(i=1;i<=n;i++)
  {
  f=f*i;
  }
return f;
}
float f(int k)
{
  float sum;
  int n;                 
  sum=0;
  for(n=0;n<=k+1;n++)
  {
sum=sum+1.0/fact(n);
  }
return sum;
}
int main()
{
 printf("%f",f(10));        
}



