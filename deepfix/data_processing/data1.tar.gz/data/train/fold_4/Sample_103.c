
#include<stdio.h>
int fact(int n)  
{
  int f;
  int i;
  f=1;
  for(i=1;i<=n;i++) 
 {
     f=f*i;  
  }
  return f; 
}

float f(int k) 
{  
   float answer; 
   int n;
   for(n=0;n<=k;n++)
      answer=answer+1.0/fact(n);  
   return answer; 
}

int main()  
{  
   float key;
   key=f(10); 
   printf("key=%f",key);
}

