
#include<stdio.h>
float fact(n)
{
  int j;
	float value=1;
  for(j=1; j<=n; j++)
  {
    value=value*j;
  }
  return value;
}

float f(int k)
{
  int i;
  float answer=0.0;
  for(i=0; i<=k; i++)
  {
	  if(fact(i)>100000)
	  {
       break;
	  }
    else
	  {
      answer=answer+(1.0/fact(i));
	  }
  }
  return answer;
}

int main()
{
  int a;
  scanf("%d", &a);
  printf("%f", f(a));
}

