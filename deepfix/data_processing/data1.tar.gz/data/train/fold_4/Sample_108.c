#include<stdio.h>

int fact(int n)
{ 
 int f,i;
 f=1;
  for(i=1;i<=n;i++)
   {
       f=f*i;
    }
return f;
 }

float f(int k)
{
  int n;
  float sum;
  sum=0;
    for(n=0;n<=k;n++)
  {
      sum=sum + 1.0/fact(n);
  }
return sum;
}

int main()
{
  float g;
    g=f(10);
  printf("%f\n",g);
  printf("%f\n",f(9));
  printf("%f\n",f(8));
  printf("%f\n",f(7));
  printf("%f\n",f(6));
  printf("%f\n",f(5));
}



