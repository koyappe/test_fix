						
#include <stdio.h>

float fact(int n)				
{						
	float kij=1;

	while(n>0){
		kij=kij*n;
		n--;
	}

	return kij;

}

float f(int k)					
{						
	int n;
	float value=0;

	for(n=0;n<=k;n++)
	{
		value = value + (1/fact(n));
	}

	return value;
}

int main()
{
	int k=1;
	float e;

	while(f(k)-f(k-1)>=0.00001)		
		k++;

	e=f(k);
		
	printf("e = %f\n",e);

	return 0;
}

