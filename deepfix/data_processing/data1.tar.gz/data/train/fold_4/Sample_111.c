
#include<stdio.h>

int fact(int n)
{
	int answer=1,i;
	for(i=1;i<=n;i++)
	{
	answer=answer*i;
	}
	return answer;
}
float f(int k)
{
	float sum=0.0;
	int v;
	for(v=0;v<=k;v++)
	{
	sum+=1.0/fact(v);
	}
	return sum;
}
int main()
{
	float sum;	
	sum=f(10.0);
	printf("%f",sum);
	return 0;
}

