
#include<stdio.h>
int fact(int n){
int x,i;
x=1;
for(i=1;i<=n;i++){
    x=x*i;
}
return x;               
}

float f(int k){
float y;
int n;
y=0;
for(n=0;n<=k;n++){
    y=y+1.0/fact(n);           
    }
return y;               
}

int main(){
int k,a;
float val;
scanf("%d",&a);
for(k=0;k<=a;k++){
val=f(k);            
printf("%f\n",val);
}
return 0;
}

#include<stdio.h>
int fact(int n){
int x,i;
x=1;
for(i=1;i<=n;i++){
    x=x*i;
}
return x;              
}

float f(int k){
float y;
int n;
y=0;
for(n=0;n<=k;n++){
    y=y+1.0/fact(n);            
    }
return y;            
}

int main(){
int k;
float val,a;
for(k=0;1;k++){            
    val=f(k);            
    printf("%f\n",val);
    a=f(k)-f(k-1);
    if(a==0){            
        break;
        }
    }
return 0;
}

