#include <stdio.h>

int fact(int n){
	int i,ans=1;
	for(i=1;i<=n;i++)
	{
		ans=i*ans;
	}
	return ans;
}


float f(int k)
{
	int i;
	float ans=0.0;
	for(i=0;i<=k;i++)
	{
	ans=ans+1.0/fact(i);
	}
	return ans;
}
int main()
{
	printf("%f",f(10));
}	

