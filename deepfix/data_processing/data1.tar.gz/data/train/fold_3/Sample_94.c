

#include <stdio.h>

int fact(int n)
{
 	int i,f;
 	f=1;
 	i=1;
 	for(i=1;i<=n;i++)
	{
  		f=f*i;
 	}
   return f;
}

float f(int k)
{
  float l=0;
  int n;
	for(n=0;n<=k;n++)
	{
		l=l+1.0/fact(n);
   }
	return l;
}
	
int main()
{
	printf("%f\n",f(10));
}

