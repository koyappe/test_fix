
#include<stdio.h>
int fact(int n)
{
		int f;
		for(f=1;n>1;n--)
		{	
		f=n*f;
		}
		return f;
}
 float f(int n)
{
		float sum=0.0;
		int i;
		for(i=0;i<=n;i++)
		{
				sum = sum + 1.0 / fact(i);
		}
		return sum;
}
int main()
{
		printf("%f\n",f(10));
}

#include<stdio.h>
int fact(int n)
{
		int f;
		for(f=1;n>1;n--)
		{	
		f=n*f;
		}
		return f;
}
 float f(int n)
{
		float sum=0.0;
		int i;
		for(i=0;i<=n;i++)
		{
		if(1.0/fact(i)<0.00001)
		{
				return sum;
		}
				sum = sum + 1.0 / fact(i);
		}
		return sum;
}
int main()
{
		printf("%f\n",f(9));
		printf("%f\n",f(300));
		return 0;
}
				
		
		


		
		


		

				
		
		
