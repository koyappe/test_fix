
#include <stdio.h>

int fact( int n)
{
     int f,k,i;
     f=1;

     for(i=1; i<=n;i++)
	{
        f=f*i;
        printf("%d\n", f);
    }
 return f;
}

float f(int n)
{
    int i;
    float sum=0;

    for(i=0;i<=n;i++)
    {
       sum=sum+1.0/fact(i);
    }
 return sum;
}

int main()
{
  printf("%f\n", f(1));
  printf("%f\n", f(2));
  printf("%f\n", f(3));
  printf("%f\n", f(10));
}

