
#include <stdio.h>
#define T 0.00001			
#define N 9999			

int fact(int n){		
	int res = n;
	if(n==0) return 1;
	while(n>1){
		res *= n-1;
		n--;
	}
	return res;
}

float f(int k)			
{
	int i;			
	float t,res;		
	float added = 0.0;		
	for(i=0;i<=k;i++)		
	{
		res = fact(i);	
		t = 1 / res;	
		added += t;	
		if(t < T) break;	
	}
	return added;		
}

int main()
{
	printf("f(1) = %f\n",f(1));	
	printf("f(2) = %f\n",f(2));
	printf("f(3) = %f\n",f(3));
	printf("f(4) = %f\n",f(4));
	printf("f(10) = %f\n",f(10));
	printf("f(N) = %f\n",f(N));	
}

