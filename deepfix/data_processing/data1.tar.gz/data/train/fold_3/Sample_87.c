#include<stdio.h>
int fact(int n)
{
	int i,f;
	f=1;
	for(i=1;i<=n;i++)
	{
		f=f*i;
	}
	return f;
}	

int main()
{
	int i,f,val,n;
	float e;
	scanf("%d",&i);
	e=0;
for(n=0;n<=i;n++)
{
val=fact(n);
e=e+1.0/val;
}
printf("%f",e);
return 0;
}

