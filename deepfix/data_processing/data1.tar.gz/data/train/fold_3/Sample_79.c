
#include <stdio.h>


float fact(int n) 
{
	float f=1;
	int i;
	for(i=1;i<n+1;i++){
		f=f*i;
	}
	return f;
}

float f(int k) 
{
	int i;
	float value=0;
	for(i=0;i<k+1;i++){
		value += 1/fact(i);
	}
	return value;
}

int main()
{
	int i,k;
	float ans;
	scanf("%d",&k);
	ans=f(k);
	printf("%f\n",ans);
}

#include <stdio.h>

float fact(int n) 
{
	float f=1;
	int i;
	for(i=1;i<n+1;i++){
		f=f*i;
	}
	return f;
}

float f(int k) 
{
	int i;
	float value=0;
	float chk, bef;
	bef=0;
	for(i=0;i<k+1;i++, bef=value){ 
		value += 1/fact(i);
		chk=value-bef;
		if(chk<0.00001){ 
			break;
		}
	}
	return value;
}

int main()
{
	int i,k;
	float ans;
	scanf("%d",&k);
	ans=f(k);
	printf("%f\n",ans);
}
