

#include<stdio.h>
int fact(int n)
{
  int f;
  int i;
  f=1;
  for(i=1;i<=n;i++)
    {
      f=f*i;
    }
   return f;
}

float f(int k)
{
   int n;
   float x;
   x=0;
 for(n=0;n<=k;n++)
    {
     
      x=x+1.0/fact(n);
    }
      return x;
}
 
int main()
{
  float y;
  y=f(10);  

  printf("%f\n",y);
}

