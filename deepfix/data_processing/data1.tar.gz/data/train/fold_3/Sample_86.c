
#include <stdio.h>
int fact(int n)
{
   int h=1,i;
   for(i=1;i<=n;i++)
   {
       h=h*i;
   }
   return h; 
}

float f(int k)  

{
   float l=0;
   int n;
      for(n=0;n<=k;n++)
   		l=l+1.0/fact(n);
   return l;
}
 
int main()
{
   printf("%f\n",f(10));
}

