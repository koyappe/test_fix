


#include<stdio.h>
int fact(n)                       
{
	int a;                    
	int i;                    
	a=1;                    
	for(i=1;i<=n;i++)         
  {
	a=a*i;
  }
	return a;            
}                              

float f(k)                    
{
int n;
float x;
n=0;
x=0.0;
for(x=0;n<k;n++)
  {
  x=x+(1.0/fact(n));             
  }
  return x;                   
}

int main()
{
  int k;                     
  float p;                     
  k=10;                       
  p=f(k);                
  printf("%f\n",p);            
	return 0;             
}
