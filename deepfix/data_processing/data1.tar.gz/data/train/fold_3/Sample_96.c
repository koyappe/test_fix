

#include<stdio.h>

int fact(n)
{
    int i,y;
    y=1;
    for(i=1;i<=n;i++){
         y = y*i;
    }
    return y;
}

float f(k)
{
    int n;
    float z;
    z=0;
    for(n=0;n<k;n++){   
         z=z+1.0/fact(n);
    }
    return z;
}    

int main()
{
    int k;
    float x;
    k=30;
    x=f(k); 
    printf("%f",x);    
}

