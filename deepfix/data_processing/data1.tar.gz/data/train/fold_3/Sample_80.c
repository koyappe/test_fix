
#include <stdio.h>

int fact(int n)
{ 
       int i;
       int f=1;
       for(i=1;i<=n;i++)
       {
           f=f*i;
       } 
       return f;
}

float f(int k)
{   
      int i; 
      float f=0;
      for(i=0;i<=k;i++)
      {
           f=f+1.0/fact(i);
      } 
      return f;
}
    
int main()
{
      float answer;
      answer=f(10);
      printf("%f\n",answer);
   
    return 0;
}

