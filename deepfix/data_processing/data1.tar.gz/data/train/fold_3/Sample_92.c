
#include<stdio.h>
int fact(int n)  
{
	int f;
	int i;
	f=1;
	for(i=1;i<=n;i++){  
	f=f*i;
}
return f;     
}


	float f(int k)
	{
		float j;
		int n;
		for(n=0;n<=k;n++)   
		{
			j=j+1.0/fact(n);
		}			
	return j;  
	}

	int main()
	{	
			float p;
			p=f(10);
			printf("answer=%f\n",p);
	}

