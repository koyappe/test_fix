

#include <stdio.h>

float n,i,j,k,sum;

int fact(int n){
       j=1;
		for(i=1;i<=n;i++)
       {
		j=j*i;
		}

	return j;
}

float f(int k){ 
	sum=0;
	for(n=0;n<=k;n++)
       {
	sum=sum + 1.0/fact(n);
	}
	return sum;
}

int main()
{
       printf("%f\n",f(10));
}


