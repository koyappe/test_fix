#include<stdio.h>

int fact(int n)
{
    int f=1,i;  

    for(i=1;i<=n;i++)  
    {
        f=f*i;
    }
    return f;  
}


float f(int k)
{
    int m;
    float sum=0;

    for(m=0;m<=k;m++)
    {
        sum=sum+1.0/fact(m);  
    }
    return sum;  
}


int main()
{
    int k;
    scanf("%d",&k);  
    printf("%f",f(k));  
    
    return 0;
}


