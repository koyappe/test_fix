
#include<stdio.h>
float fact(int n)
{
  int j,i;
  j=1;
  for(i=1; i<n+1;i++){
   j=j*i;
  }
  return j;
}
float f(int k)
{
	int i;
  float value=0;
	for(i=0;i<k+1;i++)
	{
    value = value + 1.0/fact(i);
	}
	return value;
}

int main()
{
  int i,k;
  float ans;
  scanf("%d",&k);
  ans = f(k);
  printf("%f\n",ans);
}

