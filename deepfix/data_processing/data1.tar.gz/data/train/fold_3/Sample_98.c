
#include <stdio.h>

int i=0,k=0;
float sum=0;

int fact(int n)
{
  int f,i;
  f=1;
  for(i=1;i<n+1;i++){
  f=f*i;
  }
 return f;
}

float f(int k)
{
  for(k=0;k<=i;k++)
  {
  sum=sum+1.0/fact(k);
  }
}

int main()
{
  scanf("%d",&i);
  f(i);
  printf("%d\n%f",fact(k),sum);
}

