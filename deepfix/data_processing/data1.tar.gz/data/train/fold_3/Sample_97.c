#include<stdio.h>
int fact(int n){
   int j,i;
   j=1;
       for(i=1;i<=n;i++){

           j=j*i;
                         }
       return j;
                }

float f(k){
    int n;
    float f;
    f=0;
        for(n=0;n<=k;n++){
           f= f + (1.0/fact(n));  
                          }
        return f;
           }
int main()
{
     int i,k;
     float a;
    scanf("%d",&k); 
     a=f(k);

     printf("%f\n",a);           
     return 0;
}

