#include <stdio.h>
int fact(int n)
{
		int X,Y;

		X=1;
		for(Y=0;Y<n;Y++){
		X*=(n-Y);
		}
		return X;
} 


float f(int k)
{
	float sum;
	float a;
		int i;
		for(i=0;i<=k;i++)
		{
			a=1.0/fact(i);
			sum=sum+a;
			if(a<=0.00001)break;
		}
	return sum;
}


int main()
{
printf("%f",f(10));
	printf("%f",f(1));
	printf("%f",f(2));	
}












