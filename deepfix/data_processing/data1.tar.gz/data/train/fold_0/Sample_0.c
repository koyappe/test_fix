#include <stdio.h>

int fact(int n){
	int res = n;
	if(n==0) return 1;
	while(n>1){				
		res *= n-1;
		n--;
	}
	return res;				
}

int main(){
	int val1,val2,n;
	
	for(n=1;n<200;n++){			
		val1 = fact(n);			
		val2 = fact(n-1);
		printf("[N=%d] N! = %d, (N-1)! = %d\n", n,val1,val2);	
		if(val1/n == val2){
			printf("OK!\n");		
		}else{
			printf("NG!\n");		
			break;
		}
	}
	return 0;
}
