int fact(int n)
{
int val = 1 ; 
int i   = 1 ;

while(i < n)
{
val = val*(i +1);

i = i+1;


}

return val;
}




int main()
{

 int a, val, i= 0;
 scanf("%d", &a);
 printf("%d\n" ,val);


	while(i < a)
	{
		val = val*(i +1);
		i = i+1;

		
		int val1 = fact(i);
		int val2 = fact(i-1);

		if(val1/i == val2){
			printf("OK\n");
		}
		else{
			printf("�_���������E�E�E�B\n");
		}
	}
}



