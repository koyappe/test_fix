
Int fact(int n)
{
	int f;
	int i;
	f=1;
	for(i=1;i<=n;i++){  
		f=f*i;  
	}
	return f;
}

int main()
{
int val1;
int val2;
int n;
for (n=2;n<=1000;n++)  
		{
		val1 = fact(n);
		val2 = fact(n-1);
			if(val1/n == val2){ 
			printf("OK\n");
				}else{
					printf("NG\n");
					break;
					}		
		}                                        
}


