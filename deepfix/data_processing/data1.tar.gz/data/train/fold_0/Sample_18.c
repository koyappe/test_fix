
#include<stdio.h>

int fact(int n)
{
  int f,i;
  f=1;
  for(i=1;i<=n;i++)
  {
  f=f*i;
  }
  return f;
}
int main()
{
  int i,val1,val2;
  for(i=2;i>0;i++)
  {
    val1 = fact(i);
    val2 = fact(i-1);

    if((val1)/i == val2)
        {
        printf("i=%d val1=%d val2=%d  OK\n",i,val1,val2);
        }
    else{
        printf("i=%d val1=%d val2=%d BAD\n",i,val1,val2);
        break;
        }
  }
}
