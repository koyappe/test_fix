

int fact(int n)
{
  int f=1;
  int i;
  for(i=1;i<n+1;i++){
    f=f*i;
    }
  return f;
}

int main()
{
  int i, val;
  for(i=1;1<101;i++){
    printf("%d\n",i);
    val = fact(i);
    printf("%d\n",val);
    int chk;
    chk = val/i;
    val = fact(i-1);
    if(chk == val){
      printf("%d��%d �Ȃ̂Ő�����\n",chk,val);
      }
    else{
      printf("%d��%d �Ȃ̂Ő������Ȃ�\n",chk,val);
      break;
      }
  }
  return 0;
}
