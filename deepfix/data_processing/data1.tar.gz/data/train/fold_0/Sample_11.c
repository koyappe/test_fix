int fact(int n)
{
 int f ,g;
 f=1;
 for(g=0;g<n;g++)
  {
   f=f*(n-g);
  }
return f;
}

int main()
{

 int i,j,val1,val2;

 for(i=1;i<30;i++)
 {
   int j=i-1;
   val1=fact(i);
   val2=fact(j);
   printf("%d\n%d\n%d\n%d\n",i,j,val1,val2);
   if(val1/i == val2)
    {
     printf("No problem\n")
    }

   else
    {
     printf("Error\n");
     break;
    }
 }
return 0;
}

