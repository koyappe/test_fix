

int fact(int n)
{
int f;
int i;
f=1;
for(i=1; i<=n; i++){
f=f*i;
}
return f;
}

int main()
{
int i =1;
int val1 =i;
int val2 =i-1;
for(i =1;i<100; i++){
val1 = fact(i);
val2 = fact(i-1);
printf("%d %d\n", val1, val2);
if(val1/i == val2){
printf("OK\n");
}else{
printf("IDIOT\n");
}
}
}



