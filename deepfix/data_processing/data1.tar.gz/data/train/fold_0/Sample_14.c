int fact(int n)
{
	int f;
	int i;
	f=1;

	for(i=1; i<=n; i++)
	{ 
		f=f*i;
	}

	return f;
}

int main()
{
 int i,val1,val2;
	for(i = 1; i < 20; i++)
	{
	val1 = fact(i);
	val2 = fact(i-1);
	if(val1/i == val2)
		{
			printf("OK\n");
		}
	else
		{
			printf("False\n");
			break;
		}
	}
}
