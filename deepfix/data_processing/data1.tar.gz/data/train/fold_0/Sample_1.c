



int fact(int n)
{
 	int i,f;
 	f=1;
 	i=1;
 	for(i=1;i<=n;i++)
	{
  		f=f*i;
 	}
 return f;
}

int main()
{
	int  val1,val2,i,n;

	for(i=2;i<=n;i++){
 		val1=fact(i);
 		val2=fact(i-1);
	 if(val1/i==val2){
   	printf("OK\n");
 	}else
		{
    printf("fail\n");
		break;
 		}
	}
}
