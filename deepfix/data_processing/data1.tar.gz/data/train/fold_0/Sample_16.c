int fact(int n)
{
  int f;
  int i;
  f=1;
  for(i=1;i<=n;i++)
 {
   f=f*i;
 }
 return f;

}
int main()
{ 
int n;
for(n=1;n<200;n++ ){
int  val1 = fact(n);
int  val2 = fact(n-1);
 if(val1/n == val2){
  printf("OK\n");
  }else{
printf("NOT OK\n");break;
}
  }
return 0;
}
