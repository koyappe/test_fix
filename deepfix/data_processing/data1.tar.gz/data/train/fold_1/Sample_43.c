int main()
{
float r1,r2,x;
char op;
while(1){ 
scanf("%f %c %f", &r1, &op, &r2);
if(op=='+'){ 
       x=r1 + r2;
}
else
if(op=='-'){ 
     x=r1 - r2;
}
else
 if(op=='*'){ 
     x=r1 * r2;
 }
 else
 if(op=='/'){ 
x=r1 / r2;
 }
 else
 {
     printf("false");
 }
     printf("%f",x);
 }
}













