int main()
{
  while(1){

	float e;
	char op;
	float e2;
	float e3;
	scanf("%f %c %f",&e,&op,&e2);
	if(op=='+')
		{
			e3=e+e2;
		}
	else if(op=='-'){
			e3=e-e2;
			}
	else if(op=='*'){
			e3=e*e2;
			}
	else if(op=='/'){
			e3=e/e2;
			}
	else{
		printf("error!");
		break;
		}
	printf("%f\n",e3);

}
}

