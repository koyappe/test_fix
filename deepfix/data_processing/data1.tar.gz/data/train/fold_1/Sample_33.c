int fact(int n)
{
  int f;
  int i;
  f=1;
  for(i=1;i<=n;i++){
    f=f*i;
  }
  return f;
}

int main()
{
int n,val1,val2; 

for(n=1;n<100;n++){

val1=fact(n);
val2=fact(n-1);
  
  if(val1/n==val2){
   printf("OK\n");
}else{
  printf("ERROR"); 
  break;
  }
 }
 return 0;
}

