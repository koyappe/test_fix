#include<stdio.h>
char main()
{
	float i;
	char j;
	float f;
	float A;
while(1)
{ 
 		scanf("%f%c%f\n",&i,&j,&f);
		if(j=='+')
   	{
			A=i+f;
		}
	else	if(j=='-')
   		{
				A=i-f;
			}
	else	if(j=='*')
   				{
						A=i*f;
				}
	else	if(j=='/')
   						{
								A=i/f;
						}	
	else printf("error\n");
	printf("%f\n",A);
}
}

