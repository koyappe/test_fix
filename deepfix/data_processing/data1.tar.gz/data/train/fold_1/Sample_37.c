
#include <stdio.h>

int main(){
	float e1,e2;										
	char op;

	while(1){
		scanf("%f %c %f", &e1, &op, &e2);				

		if(op=='q') break;								

		switch(op){										
			case '+':
				printf("%f + %f = %f\n",e1,e2,e1+e2);	
				break;
			case '-':
				printf("%f - %f = %f\n",e1,e2,e1-e2);	
				break;
			case '*':
				printf("%f * %f = %f\n",e1,e2,e1*e2);	
				break;
			case '/':
				if(!e2){
					printf("0�ŏ��Z���Ă��܂�\n");		
					break;
				}
				printf("%f / %f = %f\n",e1,e2,e1/e2);	
				break;
			default:
				printf("�s���ȉ��Z�q�ł�\n");			
				break;
		}
		fflush(stdin);									
	}
}
