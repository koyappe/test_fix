
main()
{
 float e1,e2,e3;
char op;
 while(1) 
 {
scanf("%f %c %f",&e1,&op,&e2);  
 
  if(op=='+')
    {
    e3=e1+e2; 
    printf("%f %c %f=%f\n",e1,op,e2,e3);
    }
  else if(op=='-')  

    {
    e3=e1-e2; 
    printf("%f %c %f=%f\n",e1,op,e2,e3);
    }
  else if(op=='*')  
    {
    e3=e1*e2;  
    printf("%f %c %f=%f\n",e1,op,e2,e3);
    }
  else if(op=='/') 
    {
    e3=e1/e2; 
    printf("%f %c %f=%f\n",e1,op,e2,e3);
    } 
  Else  
    {
printf("error"); 
    }     
 }
}
