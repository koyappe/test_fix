int fact(int n)
{
  int i=1,x=1;
  for(x=n;x!=0;x--){
    i=i*x;
  }
  return i;
}

int main()
{
  int val1;
  int val2;
  int n;
  for(n=1;n<30;n++){
    val1 = fact(n);
    val2 = fact(n-1);
      if(val1/n == val2){
        printf("OK\n");
      }
      else{
        printf("NG%d\n",n);
        break;
      }
  }
}
