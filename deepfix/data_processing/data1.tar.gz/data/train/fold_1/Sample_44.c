
int main()
{
while(1){
float e1;
char op;
float e2,e3;
 scanf("%f %c %f", &e1, &op, &e2);
if(op == '+')e3 = e1+e2;
else if(op == '*')e3 = e1*e2;
else if(op == '-')e3 = e1-e2;
else if(op == '/')e3 = e1/e2;
else {printf("�G���[");
break;}
 
printf("%f\n",e1,op,e2,e3);

}
}

