
int fact(int m)
{
 int f, n;
 n=1;
 for(f=1; f<m ; f++){
 n*=f+1;
}
return n;
}




int main()
{
int n, val1, val2;
for(n=1; n<12; n++)
 {
val1=fact(n);
val2=fact(n-1);
if(val1/n==val2)
 {
printf("%d:�����Ă��\n",n);
 }
else
  {
printf("%d:�Ԉ���Ă��\n",n);
}
 }
}
