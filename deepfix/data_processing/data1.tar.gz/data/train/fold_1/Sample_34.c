int fact(int n)
{
 int i,f;
 f=1;

 for(i=2;i<=n;i++)
  {
    f=f*i;
  }
  return f;
}

int main()
{
 int i,val1,val2,n;
 for(i=2;i<n;i++)
  {
     val1=fact(i);
     val2=fact(i-1);
 
     if(val1/i == val2)
     {
       printf("%d���\n",i-1);
       printf("OK\n");
     }
     else
     {
        printf("%d���\n",i-1);
        printf("FALSE\n");
        break;
     }
   }
  return 0;
}

