

int main()
{
float e1;
float e2;
char op;
float e3;
while(1)
	{
	scanf("%f %c %f", &e1, &op, &e2);		
	if(op=='+')
			{
			e3=e1+e2;
			}
	else if(op=='-')   
			{
			e3=e1-e2;
			}
	else if(op=='*')    
			{
			e3=e1*e2;  
			}
	else if(op=='/')    
			{
			e3=e1/e2; 
			}
	Else  
	{
	printf("op�̒l������������܂���B\n");
	break;
	}
	printf("%f %c %f = %f\n",e1,op,e2,e3);
	}
}
