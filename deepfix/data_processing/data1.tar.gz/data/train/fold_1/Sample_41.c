
#include<stdio.h>

int main()
{
 float i;
	char j;
	float k;
	float l;
 int m;
	while(1)
	{
	 m=scanf("%f %c %f",&i,&j,&k);
   	 if(m!=3)break;
  	 if(j=='+')
	  {
	   l=i+k;
	   printf("%f\n",l);
	  }
    	else if(j=='-')
	  {
	   l=i-k;
	   printf("%f\n",l);
	  }
	else if(j=='*')
	  {
	   l=i*k;
	   printf("%f\n",l);
	  }
	else if(j=='/')
	  {
	   l=i/k;
	   printf("%f\n",l);
	  }
    	else
	  printf("error\n",l);
	}
}

