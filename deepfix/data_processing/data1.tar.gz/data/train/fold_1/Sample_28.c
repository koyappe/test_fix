

int fact(int n) 
{
  int i,f=0;
  for(i=1;i<=n;i++)
  {
  f=f*i;
  }
  return f;
}

int main()
{
  int n,val1,val2;
  for(n=1;n<1000;n++)
{
  val1=fact(n);
  val2=fact(n-1);
  if(val1/n==val2)
  {
  printf("OK\n");
  }
   else
   {
  printf("NG\n");
   break; 
   
   }
}
return 0; 
}

