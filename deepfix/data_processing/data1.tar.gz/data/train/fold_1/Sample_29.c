int fact(int n)
{
  int f,i;
  f=1;
  for(i=1; i<n+1;i++){
    f=f*i;
  }
  return f;
}

int main()
{
  int i,val1,val2;
  for(i=1;i<50;i++){
    printf("%d\n",i);
    val1 = fact(i);
    val2 = fact(i-1);
    if(val1/i==val2){
      printf("OK\n");
    }
    else{
      printf("NG\n");
      break;
    }
  }
  return 0;
}

