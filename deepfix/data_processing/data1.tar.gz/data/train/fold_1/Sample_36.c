


int main()
{
float ans,e1,e2; 
char op;

while(1) 
{
scanf("%f %c %f", &e1, &op, &e2);

    if(op=='+') 
    {
        ans=e1 + e2;
    }
    else

    if(op=='-') 
    {
        ans=e1 - e2;
    }
    else

    if(op=='*') 
    {
        ans=e1 * e2;
    }
    else

    if(op=='/') 
    {
        ans=e1 / e2;
    }
    else
    
{
printf("ERROR ���̓��͎͂�t���܂���\n");
}
printf("ANSWER=%f\n",ans); 
}
}
