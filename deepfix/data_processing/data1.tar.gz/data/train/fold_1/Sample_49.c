int main()
{
   char op;
   float e1, e2, e3;
     while(1)
     {
     scanf("%f %c %f", &e1, &op, &e2); 
     if(op == '+') 
     {
       e3 = e1 + e2;
     }
     else if(op == '-') 
     {
        e3 = e1 - e2;
     }
     else if(op == '*') 
     {
        e3 = e1 * e2;
     }
     else if(op == '/') 
     {         
        e3 = e1 / e2;
     }    
     else 
     {
       printf("error");
     }   
 printf("%f\n", e3);
     }
}


