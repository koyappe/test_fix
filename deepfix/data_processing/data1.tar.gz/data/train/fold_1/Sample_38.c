
int main()
{
float e1,e2,answer;      
char op;            
while(1)         
{
scanf("%f %c %f",&e1, &op, &e2);   
if(op == '+')
  {
  answer = e1 + e2;
  }
else if(op == '-' )
  {
  answer = e1 - e2;
  }
else if(op == '*')
  {
  answer = e1 * e2;
  }
else if(op == '/')        
  {
  answer = e1 / e2;
  }
else
{
printf("error\n");     
}  
printf("%f\n",answer);     
}  
}


  
