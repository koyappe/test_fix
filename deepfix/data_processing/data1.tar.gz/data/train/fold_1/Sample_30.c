#include <stdio.h>

int fact(int n)
{
	int f;
	int a;
	f=1;
	a=1;
	while(a<=n)
	{
	f=f*a;
	a++;
	}
	return f;
}

int main()
{
	int i, j, val1, val2;
	scanf("%d", &i);	
	scanf("%d", &j);	
	while(i<=j)
		{
		val1 = fact(i);
		val2 = fact(i-1);
		printf("%d ", val1/i);	
		printf("%d ", val2);	
		if(val1/i == val2)
			{
			printf("OK\n");	
			}
		else
			{
			printf("NO\n");	
			}
		i++;
		}
	return 0;
}
