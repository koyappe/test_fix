int fact(int n)
{
  int f,i;
  f=1;
  for(i=1;i<=n;i++)
{
    f=f*i;
  }
  return f;
}

int main()
{
int val1;
int val2;
int i;
int val;
for(i=1;i<100;i++)
{
  val1=fact(i);
  val2=fact(i-1);
  printf("i=%d\n",i);
  if(val1/i==val2)
{
    printf("OK\n");
  }else{
    printf("NG\n");
    break;
  }
}
return 0;
}}

