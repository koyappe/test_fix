
int main()
{
float e1;
char op;
float e2;
scanf("%f %c %f",&e1, &op, &e2);
switch(op){
    case '+':printf("%f",e1+e2);
    break;
    case '-':printf("%f",e1-e2);
    break;
    case '*':printf("%f",e1*e2);
    break;
    case '/':printf("%f",e1/e2);
    break;
    
    }
}

int main()
{
float e1;
char op;
float e2;
while(1)
  {
scanf("%f %c %f",&e1, &op, &e2);
switch(op)
    {
    case '+':printf("%f\n",e1+e2);
    break;
    case '-':printf("%f\n",e1-e2);
    break;
    case '*':printf("%f\n",e1*e2);
    break;
    case '/':printf("%f\n",e1/e2);
    break;
    default:printf("���͂�����������܂���");
    break;

     }
  }
}
