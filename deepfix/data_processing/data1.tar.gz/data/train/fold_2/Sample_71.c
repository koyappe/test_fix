main(){
 
float e1,e2,a;
char op;
scanf("%f %c %f\n",&e1,&op,&e2);
while(1){
if(op=='+'){
	a=e1+e2;
	printf("%f %c %f = %f\n",e1,op,e2,a);
}
else if(op=='-'){
	a=e1-e2;
	printf("%f %c %f = %f\n",e1,op,e2,a);
}
else if(op=='*'){
	a=e1*e2;
	printf("%f %c %f = %f\n",e1,op,e2,a);
}
else if(op=='/'){
	a=e1/e2;
	printf("%f %c %f = %f\n",e1,op,e2,a);
}
else{
printf("���Z�q������������܂���B\n");
}
}
}

