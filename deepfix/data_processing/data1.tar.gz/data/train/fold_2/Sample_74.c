#include<stdio.h>

int main()
{
float e1, e2, a;	
char op;		
while(1)		
{

	scanf("%f %c %f", &e1, &op, &e2);			

	switch(op)					
		{
		case '+':					

		a = e1 + e2;
		printf("%f %c %f = %f\n",e1, op, e2, a);
		break;

		case '-':					
		a = e1 - e2;
		printf("%f %c %f = %f\n",e1, op, e2, a);
		break;

		case '*':					
		a = e1 * e2;
		printf("%f %c %f = %f\n",e1, op, e2, a);
		break;

		case '/':					
		if (e2 == 0)				
			{
			printf("0�ŏ��Z���Ă���s��\n"); 
			break;
			}
		a = e1 / e2;
		printf("%f %c %f = %f\n",e1, op, e2, a);
		break;

		default:					
		printf("�s���ȉ��Z�q�ł���");
		break;
		}
	}
}


