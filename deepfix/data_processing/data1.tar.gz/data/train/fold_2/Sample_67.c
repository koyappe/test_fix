
int main(){
int i,j,val1,val2;	
for(i=0;i<3;i++){	
		for(j=0;j<3;j++){	
			val1=(i==j);	
			printf("%d==%d is %d\n",i,j,val1);	
			val2=(i!=j);	
			printf("%d!=%d is %d\n",i,j,val2);	
		}
	}
}


int main(){
int val1,val2,val3;	
val1=10-4-3;	
val2=10-(4-3);	
val3=(10-4)-3;	
printf("normal:%d, right:%d, left:%d",val1,val2,val3);
}


int main()
{
	if(2) printf("then is executed when %d\n",2);	
	if(1) printf("then is executed when %d\n",1); 	
	if(0) printf("then is executed when %d\n",0); 	
	if(-1) printf("then is executed when %d\n",-1); 	
}



int true()	
{
	printf("True ");
	return 1;
}

int false()	
{
	printf("False ");
	return 0;
}

int main(){
	printf("%d&&%d is %d\n",0,0,false()&&false());
	printf("%d&&%d is %d\n",0,1,false()&&true());
	printf("%d&&%d is %d\n",1,0,true()&&false());
	printf("%d&&%d is %d\n",1,1,true()&&true());
	printf("%d||%d is %d\n",0,0,false()||false());
	printf("%d||%d is %d\n",0,1,false()||true());
	printf("%d||%d is %d\n",1,0,true()||false());
	printf("%d||%d is %d\n",1,1,true()||true());
}


int main(){
	float e1,e2;	
	char op;		
	scanf("%f %c %f",&e1,&op,&e2);	
	switch(op){	
		case '+':	
		printf("%f %c %f = %f\n",e1,op,e2,e1+e2);
		break;
		case '-': 	
		printf("%f %c %f = %f\n",e1,op,e2,e1-e2);
		break;
		case '*': 	
		printf("%f %c %f = %f\n",e1,op,e2,e1*e2);
		break;
		case '/': 	
		printf("%f %c %f = %f\n",e1,op,e2,e1/e2);
		break;
	}
}



int main(){
	float e1,e2;
	char op;
	while(1){
		scanf("%f %c %f",&e1,&op,&e2);
		switch(op){
			case '+':
				printf("%f %c %f = %f\n",e1,op,e2,e1+e2);
				break;
			case '-':
				printf("%f %c %f = %f\n",e1,op,e2,e1-e2);
				break;
			case '*':
				printf("%f %c %f = %f\n",e1,op,e2,e1*e2);
				break;
			case '/':
				printf("%f %c %f = %f\n",e1,op,e2,e1/e2);
				break;
			default:
				printf("�u���� ���Z�q �����v�œ��͂��Ă��������B\n");
				break;
		}
	}
}

