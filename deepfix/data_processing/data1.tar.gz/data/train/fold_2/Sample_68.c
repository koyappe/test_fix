

int main()
{   
    float answer;                    
    float e1;                        
    float e2;                  
    char  op;                      
    scanf("%f %c %f",&e1,&op,&e2);
    if(op=='+'){                     
       answer=e1+e2;
       printf("answer=%f\n",answer);
    }else if(op=='-'){               
       answer=e1-e2;
       printf("answer=%f\n",answer);
    }
     else if(op=='*'){                
       answer=e1*e2;
       printf("answer=%f\n",answer);
    }
     else if(op=='/'){               
       answer=e1/e2;
       printf("answer=%f\n",answer);
    }
     
}

