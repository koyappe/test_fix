
#include <stdio.h> 

int main()
{
		float s1 = 0, s2 = 0;
		char z;

while(1)
	{		
		scanf("%f %c %f", &s1, &z, &s2);
		printf("\n");

		if(z == '+')printf("%f %c %f = %f\n",s1,z,s2,s1 + s2);
		else if(z == '-')printf("%f %c %f = %f\n",s1,z,s2,s1 - s2);
		else if(z == '*')printf("%f %c %f = %f\n",s1,z,s2,s1 * s2);
		else if(z == '/')printf("%f %c %f = %f\n",s1,z,s2,s1 / s2);
		else
				{
					printf("�Ή����Ă��Ȃ����Z�q�ł��B\n\n");
					break;
				}
		s1 = 0, s2 = 0;
	}

}

