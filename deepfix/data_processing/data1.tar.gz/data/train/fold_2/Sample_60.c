
#include<stdio.h>
char main(){

float i,k,X;
char j;
int n;
while(1)
   {
n=scanf("%f %c %f",&i,&j,&k);
if(n!=3)break;

if(j=='+'){
	X = i+k;
printf("%f",X);
}
   else if(j=='-'){
	X = i-k;
   printf("%f",X);
   }
       else if(j=='*'){
	    X = i*k;
       printf("%f",X);
       }
           else if(j=='/'){
	        X = i/k;
           printf("%f",X);
           }
else 
printf("error");
    }

}



