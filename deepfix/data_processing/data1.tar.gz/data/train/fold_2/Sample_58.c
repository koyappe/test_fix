int main()
{
   float e1, A , e2;
   char op;
  while(1)
    {
       scanf("%f %c %f", &e1, &op, &e2);

    if(op == '+'){ 
       A = e1 + e2;
                 }
    else
    if(op == '-'){
       A = e1 - e2;
                 }
    else      
    if(op == '*'){ 
       A = e1 * e2;
                 }
    else
    if(op == '/'){ 
       A = e1 / e2;
                 }
    else{
      printf("error%c\n",op);
        }  
    printf("A%f\n",A);
 }
}
