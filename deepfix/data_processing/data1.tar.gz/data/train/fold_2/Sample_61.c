#include<stdio.h>
int main()
{
	float e1,e2,A;
	char op;
  int se;
	while(1){
         se=scanf("%f %c %f", &e1, &op, &e2);
         if(se!=3)break;
				if(op=='+')
				{
					A=e1+e2;
					printf("%f\n",A);
				}
				else if(op=='-')
				{
					A=e1-e2;
					printf("%f\n",A);
				}
				else if(op=='*')
				{
					A=e1*e2;
					printf("%f\n",A);
				}
				else if(op=='/')
				{
					A=e1/e2;
					printf("%f\n",A);
				}
				else
					printf("Error");
		}
}

