

int main()
{
 float e1, e2, a;
 char op;
 while(1)
  { 
   scanf("%f %c %f", &e1, &op, &e2);
   if(op == '+')
    {
     a = e1 + e2;
    }
   else if(op == '-')
    {
     a = e1 - e2;
    }
   else if(op == '*')
    {
     a = e1 * e2;                     
    }
   else if(op == '/')
    {
      a = e1 / e2;                
    }
   else{
    printf("error\n");
    break;
    }
  printf("%f\n",a);            
 }
}
