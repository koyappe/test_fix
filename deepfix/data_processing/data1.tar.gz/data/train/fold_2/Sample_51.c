int main()
{
       float e1,e2;
       char op;
      while(1){ 
         scanf("%f %c %f", &e1, &op, &e2);

    switch(op){
                 case '+':
                 printf("=%f\n",e1 + e2);
                                   break;
                 case '-':
                 printf("=%f\n",e1 - e2);
                                   break;
                 case '*':                      
                 printf("=%f\n",e1 * e2);
                                   break;
                 case '/':                      
                 printf("=%f\n",e1 / e2);       
                                   break;
              
                 default:                     
                 printf("erorr\n");
                                   break;
                  
}

                    
}
        
          return 0;
}



