
#include<stdio.h>

int main(){
float e1,e2;
char op;

while(1){
	scanf("%f %c %f",&e1,&op,&e2);

		if(op=='+'){
		printf("%f+%f=%f\n",e1,e2,e1+e2);
		}
		else{
			if(op=='-'){
			printf("%f-%f=%f\n",e1,e2,e1-e2);
			}
			else{
				if(op=='*'){
				printf("%f*%f=%f\n",e1,e2,e1*e2);
				}
				else{
					if(op=='/'){
					printf("%f/%f=%f\n",e1,e2,e1/e2);	
					}
					else{
					printf("�������l���Ⴂ�܂�\n");
					}
				}
			}
		}
	fflush(stdin);
	}
}



